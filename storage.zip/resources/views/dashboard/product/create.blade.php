@extends('components.layout')
@section('container')

<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h4 class="text-themecolor">Product Create</h4>
            </div>
            <div class="col-md-7 align-self-center text-right">
                <div class="d-flex justify-content-end align-items-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Product</a></li>
                        <li class="breadcrumb-item active">Create</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{route('dashboard.product.store')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-3">
                                <label for="formFile" class="form-label">Product Image</label>
                                <input class="form-control" required name="image" type="file" id="formFile">
                              </div>
                            <div class="mb-3">
                              <label for="exampleInputPassword1" class="form-label">Product Name </label>
                              <input type="text" class="form-control" required name="p_name" id="exampleInputPassword1">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Product Price </label>
                                <input type="text" class="form-control" required name="p_price" id="exampleInputPassword1">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Product Description </label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" name="p_desc" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <select class="form-control" name="cat_id" aria-label="Default select example">
                                    <option selected disabled>-- Category Select --</option>
                                    @if(count($category) > 1)
                                        @foreach($category as $val)
                                            <option value="{{$val['id']}}">{{$val['name']}}</option>
                                        @endforeach
                                    @elseif(count($category) == 0)
                                    @else
                                    <option value="{{$category[0]['id']}}">{{$category[0]['name']}}</option>
                                    @endif  
                                  </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Create</button>
                          </form>
                    </div>
                </div>
            </div>   
        </div>
    </div>
</div>

@endsection