<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Validator;
use Intervention\Image\Facades\Image;

class UserController extends Controller
{
    public function index(){
        $user = User::all();
        return view('dashboard.users.index' , ['data' => $user]);
    }

    public function create(){
        return view('dashboard.users.create');
    }

    public function store(Request $request){
        // return $request->all();

        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'username'=>'required',
            'email'=>'required',
            'password'=>'required',
            'phone_number'=>'required',
            'address'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
        ]);

        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $find = User::where('username' , $request->username)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $user = new User;
                if(isset($request->image))
                {
                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/profileImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $user->user_image = $input['imagename'];
                }
    
                $user->username = $request->username;
                $user->email = $request->email;
                $user->phone_number = $request->phone_number;
                $user->address = $request->address;
                $user->password = $request->password;
                $user->status = 1;
                $user->save();
                return redirect(route('dashboard.user.index'))->with('create' , "true");
            }
        }
    }

    public function delete($id){
        $user = User::find($id);
        $user->delete();
        return redirect(route('dashboard.user.index'));
    }

    public function edit($id){
        $user = User::find($id);
        return view('dashboard.users.edit' , ['data' => $user]);
    }

    public function update(Request $request){
        // return $request->all();

        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'username'=>'required',
            'email'=>'required',
            'password'=>'required',
            'phone_number'=>'required',
            'address'=>'required',
            'hidden_id'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
        ]);

        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $find = User::where('username' , $request->username)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $user = User::find($request->hidden_id);
                if(isset($request->image))
                {
                    if(isset($user->user_image) && !empty($user->user_image)){
                        $oldImagePath = $user->user_image;
                        $str_img = str_replace(url('/') , "" ,$oldImagePath);
                        $image_remove = substr($str_img, 1);
                        unlink($image_remove);
                    }

                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/profileImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $user->user_image = $input['imagename'];
                }

                $user->username = $request->username;
                $user->email = $request->email;
                $user->phone_number = $request->phone_number;
                $user->address = $request->address;
                $user->password = $request->password;
                if($request->status == "Active"){
                    $user->status = 1;
                }else{
                    $user->status = 0;
                }
                $user->update();
                return redirect(route('dashboard.user.index'))->with('create' , "true");
            }
        }
    }

    public function login_api(Request $req){
        $user = User::where('username', $req->username)->where('password', $req->password)->where('status' , 1)->first();
        if($user){
            // return 1;
            if (empty($user)) {
                return response([
                    'message' => ['These credentials do not match our records.']
                ], 404);
            }
        
            $token = $user->createToken('my-app-token')->plainTextToken;
        
            $response = [
                'user' => $user,
                'token' => $token
            ];
        
            return response($response, 201);
        }else{
            return response([
                'message' => ['These user doesnot exsist.']
            ], 404);
        }
    }

    public function signup_api(Request $req){
        $validateData = Validator::make($req->all(),
        [
            'username'=>'required',
            'email'=>'required',
            'password'=>'required',
            'phone_number'=>'required',
            'address'=>'required',
            // 'image'=>'required|mimes:jpeg,png,jpg',
        ]);

        if($validateData->fails()){
            return response([
                'message' => ['These credentials do not stored in databse username must be have min 4 character email and password is required.']
            ], 400);
        }else{
            $check = User::where('username',$req->username)->count();
            if($check > 0 ){
                return response([
                    'message' => ['The username is already exsist.']
                ], 400);
            }else{
                $user = new User;
                $user->username = $req->username;
                $user->email = $req->email;
                $user->password = $req->password;
                $user->address = $req->address;
                $user->phone_number = $req->phone_number;
                if(isset($req->image))
                {
                    $image = $req->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/profileImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $user->user_image = $input['imagename'];
                }
                $user->status = 1;  
                $save = $user->save();
                if($save == 1){
                    $token = $user->createToken('my-app-token')->plainTextToken;
                    $response = [
                        'data' => $user,
                        'token' => $token
                    ];
                    return response($response, 201);
                } else{
                    return response([
                        'message' => ['These credentials do not stored in databse username must be have min 4 character email and password is required.']
                    ], 400);
                }
            }
        }
    }

}
