<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\banner;
use Intervention\Image\Facades\Image;
use Validator;
class BannerController extends Controller
{
    public function index(){
        $banner = banner::all();
        return view('Banner.index' , ['data' => $banner]);
    }

    public function create(){
        return view('Banner.create');
    }

    public function store(Request $request){
        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg'
        ]);
        
        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $banner = new banner;
            if(isset($request->image))
            {
                $image = $request->file('image');
                $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                $destinationPath = public_path('upload/bannerImage/');
                $img = Image::make($image->getRealPath());
                $img->resize(200, 200, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'.$input['imagename']);
                
                $destinationPath = public_path('/images');
                $image->move($destinationPath, $input['imagename']);
                $banner->image = $input['imagename'];
            }
            $banner->status = 1;
            $banner->save();

            return redirect(route('dashboard.banner.index'))->with('create' , "true");
        }
    }

    public function update(Request $request){
        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
            'id' =>'required'
        ]);
        
        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $banner = banner::find($request->id);
            if(isset($request->image))
            {
                $image = $request->file('image');
                $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                $destinationPath = public_path('upload/bannerImage/');
                $img = Image::make($image->getRealPath());
                $img->resize(200, 200, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'.$input['imagename']);
                
                $destinationPath = public_path('/images');
                $image->move($destinationPath, $input['imagename']);
                $banner->image = $input['imagename'];
            }
            if($request->status == "Active"){
                $banner->status = 1;
            }else{
                $banner->status = 0;
            }
            $banner->update();

            return redirect(route('dashboard.banner.index'))->with('create' , "true");
        }
    }

    public function delete($id){
        $banner = banner::find($id);
        $banner->delete();
        return back();
    }

    public function edit($id){
        // return 1;
        $banner = banner::find($id);
        return view('Banner.edit' , ['data' => $banner]);
    }

    public function fetch_api(Request $req , $id=null){
        if(isset($id) && !empty($id)){
             $banner = banner::where('id' , $id)->where('status' , 1)->get();
            if(count($banner) > 0){                
                return response([
                    'message' => ['Banner Data is Exsist.'],
                    'data' => $banner
                ], 200);
            }else{
                return response([
                    'message' => ['These Banner Data Does not Exsist.']
                ], 200);
            }
        }else{
            $banner = banner::all()->where('status' , 1);
            if(count($banner) > 0){
                return response([
                    'message' => ['Data is Available'],
                    'data' => $banner
                ], 200);
            }else{
               return response([
                   'message' => ['Data is not Available'],
               ], 200);
            }
        }
    }

}
