<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Validator;
use Intervention\Image\Facades\Image;

class CategoryController extends Controller
{
    //
    public function index(){
        $category = Category::all();
        return view('dashboard.category.index' , ['data' => $category]);
    }

    public function create(){
        return view('dashboard.category.create');
    }

    public function store(Request $request){
        // return $request->all();

        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
            'cat_name'=>'required',
        ]);

        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $find = Category::where('name' , $request->cat_name)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $category = new Category;
                if(isset($request->image))
                {
                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/categoryImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $category->image = $input['imagename'];
                }
    
                $category->name = $request->cat_name;
                $category->status = 1;
                $category->save();
                return redirect(route('dashboard.category.index'))->with('create' , "true");
            }
        }
    }

    public function delete($id){
        $Category = Category::find($id);
        $Category->delete();
        return redirect(route('dashboard.category.index'));
    }

    public function edit($id){
        $Category = Category::find($id);
        return view('dashboard.category.edit' , ['data' => $Category]);
    }

    public function update(Request $request){
        // return $request->all();
        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'image'=>'required',
            'cat_name'=>'required',
            'hidden_id'=>'required',
        ]);

        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $find = Category::where('name' , $request->cat_name)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $category = Category::find($request->hidden_id);
                if(isset($request->image))
                {
                    $oldImagePath = $category->image;
                    $str_img = str_replace(url('/') , "" ,$oldImagePath);
                    $image_remove = substr($str_img, 1);
                    
                    unlink($image_remove);

                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/categoryImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $category->image = $input['imagename'];
                }
    
                $category->name = $request->cat_name;
                if($request->status == "Active"){
                    $category->status = 1;
                }else{
                    $category->status = 0;
                }
                $category->update();
                return redirect(route('dashboard.category.index'))->with('update' , "true");
            }
        }
    }

    public function fetch_api(Request $req , $id=null){
        if(isset($id) && !empty($id)){
            $category = Product::where('category_id',$id)->where('status' , 1)->get();
            if(count($category) > 0){                
                return response([
                    'message' => ['Category Data is Exsist.'],
                    'data' => $category
                ], 200);
            }else{
                return response([
                    'message' => ['These Category Data Does not Exsist.']
                ], 200);
            }
        }else{
            $category = Category::all()->where('status' , 1);
            if(count($category) > 0){
                return response([
                    'message' => ['Data is Available'],
                    'data' => $category
                ], 200);
            }else{
               return response([
                   'message' => ['Data is not Available'],
               ], 200);
            }
        }
    }

}
