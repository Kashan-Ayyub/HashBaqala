<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Category;
use Validator;
use Intervention\Image\Facades\Image;

class ProductController extends Controller
{
    //
    public function index(){
        $product = Product::select("products.*" , "categories.name")->join("categories" , "categories.id" , "=" , "products.category_id")->get();
        return view('dashboard.product.index' , ['data' => $product]);
    }

    public function delete($id){
        $Category = Product::find($id);
        $Category->delete();
        return redirect(route('dashboard.product.index'));
    }

    public function create(){
        $category = Category::all();
        return view('dashboard.product.create' , ['category' => $category]);
    }

    public function store(Request $request){
        // return $request->all();

        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'p_name'=>'required',
            'p_price'=>'required',
            'cat_id'=>'required',
            'p_desc'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
        ]);

        if($validateData->fails()){
            return back()->with('create_false' , 'Please fill all credentials.');
        }else{
            $find = Product::where('p_name' , $request->p_name)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $product = new Product;
                if(isset($request->image))
                {   
                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/productImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $product->product_image = $input['imagename'];

                }
    
                $product->p_name = $request->p_name;
                $product->price = $request->p_price;
                $product->description = $request->p_desc;
                $product->category_id = $request->cat_id;
                $product->status = 1;
                $product->save();
                return redirect(route('dashboard.product.index'))->with('create' , "true");
            }
        }
    }

    public function edit($id){
        $product = Product::find($id);
        $category = Category::all();
        return view('dashboard.product.edit' , ['data' => $product , "category" => $category]);
    }

    public function update(Request $request){
        // return $request->all();
        $validateData = Validator::make($request->all(),
        [
            '_token'=>'required',
            'p_name'=>'required',
            'p_price'=>'required',
            'hidden_id'=>'required',
            'cat_id'=>'required',
            'p_desc'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg',
        ]);

        if($validateData->fails()){
            return back()->with('update_false' , 'Please fill all credentials.');
        }else{
            $find = Product::where('p_name' , $request->p_name)->get();
            if(count($find) > 0){
                return back()->with('name_exsist' , 'Please fill all credentials.');
            }else{
                $product = Product::find($request->hidden_id);
                if(isset($request->image))
                {
                    if(isset($product->product_image) && !empty($product->product_image)){
                        $oldImagePath = $product->product_image;
                        $str_img = str_replace(url('/') , "" ,$oldImagePath);
                        $image_remove = substr($str_img, 1);
                        
                        unlink($image_remove);
                    }

                    $image = $request->file('image');
                    $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                
                    $destinationPath = public_path('upload/productImage/');
                    $img = Image::make($image->getRealPath());
                    $img->resize(200, 200, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($destinationPath.'/'.$input['imagename']);
            
                    $destinationPath = public_path('/images');
                    $image->move($destinationPath, $input['imagename']);
                    $product->product_image = $input['imagename'];
                }

                $product->p_name = $request->p_name;
                $product->price = $request->p_price;
                $product->description = $request->p_desc;
                $product->category_id = $request->cat_id;
                if($product->status == "Active"){
                    $product->status = 1;
                }else{
                    $product->status = 0;
                }
                $product->update();
                return redirect(route('dashboard.product.index'))->with('update' , "true");
            }
        }
    }

    public function fetch_api(Request $req , $id=null){
        if(isset($id) && !empty($id)){
            $product = Product::where('id',$id)->where('status' , 1)->get();
            if(count($product) > 0){                
                return response([
                    'message' => ['Category Data is Exsist.'],
                    'data' => $product
                ], 200);
            }else{
                return response([
                    'message' => ['These Category Data Does not Exsist.']
                ], 200);
            }
        }else{
            $product = Product::all()->where('status' , 1);
            if(count($product) > 0){
                return response([
                    'message' => ['Data is Available'],
                    'data' => $product
                ], 200);
            }else{
               return response([
                   'message' => ['Data is not Available'],
               ], 200);
            }
        }
    }
}
