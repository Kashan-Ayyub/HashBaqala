<?php

use App\Http\Controllers\BannerController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('category/{id?}', [CategoryController::class,"fetch_api"])->name('category.api');
Route::get('product/{id?}', [ProductController::class,"fetch_api"])->name('product.api');
Route::get('banner/{id?}', [BannerController::class,"fetch_api"])->name('banner.api');

Route::controller(UserController::class)->group(function () {
    Route::post('login', "login_api")->name('user.api.login');
    Route::post('signup', "signup_api")->name('user.api.signup');
});